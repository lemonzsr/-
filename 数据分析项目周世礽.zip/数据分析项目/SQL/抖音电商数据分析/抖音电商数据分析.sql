select *
from user
limit 10;

alter table user
drop column `MyUnknownColumn` ,  #修改列时，应当用反引号包裹列名
drop column `Unnamed: 0` ;

#如果对主键进行修改，则会导致安全问题，可以手动关闭
SET SQL_SAFE_UPDATES = 0;
update `user`   #update语句不需要table
set User_ID=replace(User_ID,'#','')
where user_id is not null and user_id like '#%';
SET SQL_SAFE_UPDATES = 1;

alter table user
modify column `Average_Order_Value` decimal(10,2);

#检查缺失值，结果显示无缺失值
SELECT *    
FROM user    
WHERE User_ID IS NULL    
OR Age IS NULL    
OR Gender IS NULL    
OR Location IS NULL    
OR Income IS NULL    
OR Interests IS NULL    
OR Last_Login_Days_Ago IS NULL    
OR Purchase_Frequency IS NULL    
OR Average_Order_Value IS NULL    
OR Total_Spending IS NULL    
OR Product_Category_Preference IS NULL    
OR Time_Spent_on_Site_Minutes IS NULL    
OR Pages_Viewed IS NULL    
OR Newsletter_Subscription IS NULL ;  

#检查重复值，发现没有重复值
select *, count(*) as duplicate_count
from user
group by 
User_ID, Age, Gender, Location, Income, Interests, Last_Login_Days_Ago, Purchase_Frequency, Average_Order_Value, Total_Spending, Product_Category_Preference, Time_Spent_on_Site_Minutes, Pages_Viewed, Newsletter_Subscription
having duplicate_count >1;

#用户整体画像分析
#1. 年龄分布
#50岁以上用户是最主要的用户年龄段区域，中间三个年龄段较为平均，20岁以下用户数量极少
select case when age<20 then '20岁以下' when age <=29 then '20岁到29岁' when age <=39 then '30岁到39岁' when age<=49 then '40岁到49岁' else '50岁以上' end as '年龄段' ,
count(*) as 用户数量, 
concat(round(count(*)*100/(select count(*) from user ),2),'%') as 用户占比
from user 
group by 年龄段
order by case 年龄段 when '20岁以下' then 1 when '20岁到29岁' then 2 when '30岁到39岁' then 3 when '40岁到49岁' then 4 when '50岁以上' then 5 end asc;

#2.性别分布
#男性用户略高于女性用户约五个百分点
select case when gender = 'Male' then '男性' else '女性' end as 性别,
count(*) as 用户数量,
concat(round(count(*)*100/(select count(*) from user),2),'%')  as 用户占比
from user
group by 性别; 

#location地区分布
#用户分布较为均衡，农村用户略低于城市和郊区用户
select location as 地区,
count(*) as 用户数量,
concat(round(count(*)*100/(select count(*) from user),2),'%')  as 用户占比
from user
group by 地区; 

#income分布
#
WITH t1 AS(    
	SELECT    
		Income,    
		ROW_NUMBER() OVER(ORDER BY Income) AS rn,    
		COUNT(*) OVER() AS cnt    
	FROM user    
),    
median AS (    
	SELECT    
		ROUND(AVG(Income), 2) AS 中位数    
	FROM t1    
	WHERE rn IN (FLOOR((cnt + 1) / 2), CEIL((cnt + 1) / 2))    
),    
stats AS (    
	SELECT    
		MIN(Income) AS 最低收入,    
		MAX(Income) AS 最高收入,    
		ROUND(AVG(Income), 2) AS 平均收入    
	FROM user    
)    
SELECT    
   s.最低收入,    
   s.最高收入,    
   s.平均收入,    
   m.中位数    
FROM stats s    
CROSS JOIN median m;  

#用户行为特征分析
#最大值、最小值、平均在站时长
select min(time_spent_on_site_minutes) as 最短在线时长, max(time_spent_on_site_minutes) as 最长在线时长, round(avg(time_spent_on_site_minutes),2) as 平均在线时长
from user;

#浏览页面数（按照兴趣分组）
#运动和时尚的总浏览量较高，旅行、科技、食物的浏览量想对较低
select interests as 兴趣, sum(pages_viewed) as 浏览页面量
from user
group by interests
order by 浏览页面量 desc;

#兴趣偏好（平均在站时长、平均浏览页面数、平均总消费）
#科技偏好：在线时长最短，浏览页面最多，消费最高。
#Technology 兴趣用户，尽管人数不最多，但消费能力最强，可重点关注。
#Fashion 和 Sports 用户，平均在站时长长，浏览页面多，互动性强。
#Travel 用户，消费相对较低，但浏览页面多，说明潜在转化空间大。
select interests as 兴趣, round(avg(time_spent_on_site_minutes),2) as 平均在站时长, round(avg(pages_viewed),2) as 平均浏览页面数, round(avg(total_spending),2) as 平均总消费
from user
group by interests
order by 平均总消费 desc;

#用户价值特征分析
#平均购买频率 / 最低 / 最高
select round(avg(purchase_frequency),2) as 平均购买频率, min(purchase_frequency) as 最低购买频率, max(purchase_frequency) as 最高购买频率
from user;

#平均客单价 / 最低 / 最高
select round(avg(average_order_value),2) as 平均客单价, min(average_order_value) as 最低客单价, max(average_order_value) as 最高客单价
from user;

#平均总消费 / 最低 / 最高
select round(avg(total_spending),2) as 平均总消费, min(total_spending) as 最低总消费, max(total_spending) as 最高总消费
from user;

#用户分类与画像分析
#RFM分析（近度、频度、额度）用于给用户分类
#ntile窗口函数将有序的数据集，按照指定的数量 n，均匀地划分成 n 个连续的组（也叫 “桶”）
CREATE TABLE rfm_customer_segment AS 
with rfm as (
     select user_id,last_login_days_ago as R, purchase_frequency as F, total_spending as M
     from user
),
rfm_score as(
select *, ntile(5) over(order by R desc) as R_score, ntile(5) over(order by F) as F_score, ntile(5) over(order by M) as M_score
from rfm
)
select user_id, R as Recency, F as Frequency, M as Monetary, R_score, F_score, M_score,
CASE      
        WHEN r.R_score >= 4 AND r.F_score >= 4 AND r.M_score >= 4 THEN '重要价值客户'    
        WHEN r.R_score >= 4 AND r.F_score >= 4 AND r.M_score < 4 THEN '潜力客户'    
        WHEN r.R_score >= 4 AND r.F_score < 4 AND r.M_score >= 4 THEN '新晋高价值客户'    
        WHEN r.R_score >= 4 AND r.F_score < 4 AND r.M_score < 4 THEN '一般新客户'    
        WHEN r.R_score < 4 AND r.F_score >= 4 AND r.M_score >= 4  THEN '重要唤回客户'    
        WHEN r.R_score < 4 AND r.F_score >= 4 AND r.M_score < 4  THEN '低成本维系客户'    
        WHEN r.R_score < 4 AND r.F_score < 4 AND r.M_score >= 4  THEN '高价值沉睡客户'    
        ELSE '流失客户'    
    END AS customer_segment
from rfm_score r
order by customer_segment;

#用户画像分析
create table user_profile_rfm (
 customer_segment varchar(10) primary key,
 user_cnt int ,
 avg_age decimal(4,1),
 avg_income int,
 dominant_gender varchar(10),
 dominant_location varchar(20),
 avg_login_gap decimal(5,1),
 avg_total_spending decimal(10,2),
 avg_time_min decimal(10,2),
 sub_rate decimal(4,2),
 top_interest varchar(50),
 top_category varchar(50)
);
insert into user_profile_rfm
with base as(
  select customer_segment, gender, location, interests, product_category_preference as category, count(*) as cnt, avg(age) as raw_avg_age, avg(income) as raw_avg_income,
  avg(last_login_days_ago) as raw_avg_login_gap, avg(total_spending) as raw_avg_total_spending, avg(time_spent_on_site_minutes) as raw_avg_time_min, avg(case when newsletter_subscription='True' then 1 else 0 end) as raw_sub_rate
  from user u join rfm_customer_segment r on u.user_id=r.user_id
  group by customer_segment, gender, location, interests, product_category_preference
),
ranked as (
select *, row_number() over(partition by customer_segment order by cnt desc) as rn
from base
),
segment_agg as (
select customer_segment, sum(cnt) as user_cnt, round(avg(raw_avg_age),1) as avg_age, round(avg(raw_avg_income),0) as avg_income, round(avg(raw_avg_login_gap),1) as avg_login_gap,
round(avg(raw_avg_total_spending),2) as avg_total_spending, round(avg(raw_avg_time_min),2) as avg_time_min, round(avg(raw_sub_rate),2) as sub_rate
from ranked
group by customer_segment
)
select sa.customer_segment, user_cnt, avg_age, avg_income, gender as dominant_gender, location as dominant_location, avg_login_gap, avg_total_spending, avg_time_min,
sub_rate, interests as top_interests, category as top_category
from segment_agg sa join ranked r on sa.customer_segment= r.customer_segment and  rn=1;
select *
from user_profile_rfm;

#商品分析（计算这八类客户的前三偏好产品，人数，各类客户及产品的平均客单价、消费总额、消费排名、品类渗透率及渗透率排名）渗透率即覆盖率
WITH segment_map AS(    
	SELECT    
		r.customer_segment,    
        u.User_ID,    
        u.product_category_preference AS category,    
        u.average_order_value,    
        u.total_spending    
    FROM rfm_customer_segment r    
    JOIN user u ON u.User_ID = r.User_ID    
),    
segment_size AS(    
	SELECT    
		customer_segment,    
        COUNT(*) AS total_cnt    
    FROM segment_map    
    GROUP BY customer_segment    
),    
segment_agg AS(    
	SELECT    
		ss.customer_segment,    
        sm.category,    
        COUNT(*) AS user_cnt,    
        ROUND(AVG(sm.average_order_value), 2) AS avg_order_val,    
        SUM(sm.total_spending) AS total_spending,    
        ROUND((COUNT(*) / ss.total_cnt) * 100, 2) AS penetration_rate_percent    
	FROM segment_map sm    
    JOIN segment_size ss ON sm.customer_segment = ss.customer_segment    
    GROUP BY ss.customer_segment, sm.category    
),    
ranked_result AS (    
	SELECT    
		customer_segment,    
		category,    
		user_cnt,    
		avg_order_val,    
		total_spending,    
		RANK() OVER(PARTITION BY customer_segment ORDER BY total_spending DESC) AS spending_rank,    
		penetration_rate_percent,    
		RANK() OVER(PARTITION BY customer_segment ORDER BY penetration_rate_percent DESC) AS penetration_rank    
	FROM segment_agg    
)    
SELECT * FROM ranked_result    
WHERE spending_rank <=3    
ORDER BY customer_segment, spending_rank; 

#区域分析（计算各区域用户人、用户占比、平均用户价值、购买频率、区域活跃度、区域总收益）
select location as 区域, count(*) as 用户人数, round(count(*)/(select count(*) from user),2) as 用户占比, round(avg(total_spending),2) as 平均用户价值,
round(avg(purchase_frequency),2) as 区域购买频率, avg(time_spent_on_site_minutes) as 区域活跃度, sum(total_spending) as 区域总收益
from user
group by location
order by 区域总收益 desc;
#不同区域内，客户类型分布
with total_user as (
select location, count(*) as user_cnt
from user
group by location
)
select u.location, customer_segment, count(*) as customer_count, round(count(*)*100/user_cnt,2) as segment_percentage
from user u join rfm_customer_segment r on u.user_id=r.user_id join total_user t on u.location=t.location
group by location, customer_segment
order by u.location asc, customer_segment desc;

#不同区域内产品类别分布情况
with total_product as (
select location, count(*) as user_totalcount
from user
group by location 
)
select u.location, product_category_preference, count(*) as user_count, round(count(*)*100/user_totalcount,2) as category_pct_in_location
from user u join total_product t on u.location =t.location
group by location, product_category_preference
order by u.location, category_pct_in_location desc;