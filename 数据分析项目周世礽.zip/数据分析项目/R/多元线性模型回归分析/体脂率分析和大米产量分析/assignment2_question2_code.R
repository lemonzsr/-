data<-read.csv("rice.csv",header=T)
attach(data)
y<-log(goutput)
d1<-ifelse(data$varieties=="high",1,0)
d2<-ifelse(data$varieties=="mixed",1,0)
rm<-lm(y~d1+d2)
summary(rm)
ano<-anova(rm)
SSR=ano[["Sum Sq"]][1]+ano[["Sum Sq"]][2]
MSR<-SSR/2
MSE<-ano[["Mean Sq"]][3]
f_statistic<-MSR/MSE
f_statistic
p_value<-1-pf(f_statistic,2,168)
p_value
vcov(rm)
sb1<-sqrt(0.02727630)
sb2<-sqrt(0.12160826)
sb2b1<-sqrt(0.12160826+ 0.02727630-2*(0.01253693))
n=length(y)
t<-c(-qt(1-0.05/2,df=n-3),qt(1-0.05/2,df=n-3))
confidence_interval_b2<-t*sb2+rm$coefficients[3]
confidence_interval_b2b1<-t*sb2b1+rm$coefficients[3]-rm$coefficients[2]
confidence_interval_b1<-t*sb1+rm$coefficients[2]
confidence_interval_b2
confidence_interval_b2b1
confidence_interval_b1
data$log_goutput<-log(data$goutput)
data$log_totlabor<-log(data$totlabor)
data$varieties<-factor(data$varieties,levels=c("trad","high","mixed"))
color_map<-c(trad="blue",high="red",mixed="green")
plot(x=data$log_totlabor,y=data$log_goutput,xlab="log(totlabor)",ylab="log(output)",col=color_map[as.character(data$varieties)],pch=16)

data_trad <- subset(data, varieties == "trad")
data_high <- subset(data, varieties == "high")
data_mixed <- subset(data, varieties == "mixed")

# 拟合各品种的回归模型（y = a + b*x）
model_trad <- lm(log_goutput ~ log_totlabor, data = data_trad)
model_high <- lm(log_goutput ~ log_totlabor, data = data_high)
model_mixed <- lm(log_goutput ~ log_totlabor, data = data_mixed)


abline(model_trad,col="blue")
abline(model_high,col="red")
abline(model_mixed,col="green")
legend(
  x = "topleft",  # 图例位置
  legend = c("trad", "high", "mixed"),
  col = c("blue", "red", "green"),
  lty = c(1, 1, 1),  # 线型对应拟合线
  pch = 16,  # 点形状与散点一致
  title = "varieties",
  bty = "n"  # 无边框
)
full_model<-lm(data$log_goutput~data$log_totlabor+d1+d2+data$log_totlabor:d1+data$log_totlabor:d2)
reduced_model<-lm(data$log_goutput~data$log_totlabor+d1+d2)
SSE_full <- sum(resid(full_model)^2)
SSE_reduced <- sum(resid(reduced_model)^2)
p_full <- length(coef(full_model))  
p_reduced <- length(coef(reduced_model)) 
n <- nrow(data)
df_interaction <- p_full - p_reduced
df_full <- n -p_full
df_full
F_stat <- ((SSE_reduced - SSE_full) / df_interaction) / (SSE_full / df_full)
p_value <- 1 - pf(F_stat, df1 = df_interaction, df2 = df_full)
p_value
summary(full_model)
summary(reduced_model)


data$log_urea <- log(data$urea)
data$log_phosphate <- log(data$phosphate)
formula_unconstrained <- log_goutput ~ log_totlabor + d1+d2 + log_urea + log_phosphate
model_unconstrained <- lm(formula_unconstrained,data=data)
data$log_fert <- data$log_urea + data$log_phosphate  # 创建新变量
formula_constrained <- log_goutput ~ log_totlabor + d1+d2 + log_fert
model_constrained <- lm(formula_constrained,data=data)
SSE_unconstrained <- sum(resid(model_unconstrained)^2)
SSE_constrained <- sum(resid(model_constrained)^2)
df_unconstrained <- df.residual(model_unconstrained)
df_constrained <- df.residual(model_constrained)
df_diff <- df_constrained - df_unconstrained  # 约束数 = 1

F_stat <- ((SSE_constrained - SSE_unconstrained) / df_diff) / 
  (SSE_unconstrained / df_unconstrained)
p_value <- 1 - pf(F_stat, df1 = df_diff, df2 = df_unconstrained)
p_value
