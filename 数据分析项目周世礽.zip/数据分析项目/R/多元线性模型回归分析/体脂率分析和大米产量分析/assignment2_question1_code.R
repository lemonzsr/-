data<-read.csv("ais.csv",header=T)
attach(data)
y<-data[,2]
bmi<-data[,1]
lbm<-data[,3]
ht<-data[,4]
wt<-data[,5]
gender<-NA
gender[data$sex=="f"]<-1
gender[data$sex=="m"]<-0
rm<-lm(y~ bmi+lbm+ht+wt+gender)
summary(rm)
aov<-anova(rm)
ssr<-0
for (i in 1:5){
  ssr=ssr+aov[["Sum Sq"]][i]
}
MsR<-ssr/5
MSE<-aov[["Mean Sq"]][6]
F_statistic<-MSR/MSE
qf(0.95,5,196)
1-pf(F_statistic,5,196)
confint(rm,level=0.99)
ssr<-aov[["Sum Sq"]][1]+aov[["Sum Sq"]][3]
msr<-ssr/2
mse<-aov[["Mean Sq"]][6]
F_statistic<-msr/mse
p_value<-1-pf(F_statistic,2,196)
p_value
coef<-rm$coefficients
estimated_pcBfat<-coef[1]+coef[2]*23+coef[3]*65+coef[4]*180+coef[5]*75+coef[6]*0
#bmi is 23, lbm is 65, ht is 180, and wt is 75
estimated_pcBfat
0.19278849+0.16441358*23+-1.22453139*65+0.06536495*180+1.02322440*75+0.93420686*0
predict(rm, data.frame(bmi=23, lbm=65, ht=180, wt=75, gender=0),interval = "confidence", level = 0.95)
#externally studentized residuals against fitted values, a normal QQ plot, a leverage plot (with cut-off line), a Cook’s distance plot and a number of DFBETAs plots
par(mfrow=c(2,2))
plot(fitted(rm), rstudent(rm),main="Externally studentised residuals vs fitted values",pch=16)
abline(0,0)
plot(rm, which=2)
plot(rm, which=4)
plot(hatvalues(rm), type = "h")
abline(h=2*6/length(y), col="red", main="Leverage")
which(hatvalues(rm)>2*6/length(y))
which(rstudent(rm)>3)
which(rstudent(rm)< -3)
head(dfbetas(rm))
par(mfrow=c(3,2))
plot(dfbetas(rm)[,2],type="h",main="bmi")
abline(h=0)
abline(h=c(-2/sqrt(202),2/sqrt(202)),col=2)
plot(dfbetas(rm)[,3],type="h",main="lbm")
abline(h=0)
abline(h=c(-2/sqrt(202),2/sqrt(202)),col=2)
plot(dfbetas(rm)[,4],type="h",main="ht")
abline(h=0)
abline(h=c(-2/sqrt(202),2/sqrt(202)),col=2)
plot(dfbetas(rm)[,5],type="h",main="wt")
abline(h=0)
abline(h=c(-2/sqrt(202),2/sqrt(202)),col=2)
plot(dfbetas(rm)[,6],type="h",main="gender")
abline(h=0)
abline(h=c(-2/sqrt(202), 2/sqrt(202)),col=2)
which(dfbetas(rm)[,2]> 2/sqrt(202))
which(dfbetas(rm)[,2]< -2/sqrt(202))
which(dfbetas(rm)[,3]> 2/sqrt(202))
which(dfbetas(rm)[,3]< -2/sqrt(202))
which(dfbetas(rm)[,4]> 2/sqrt(202))
which(dfbetas(rm)[,4]< -2/sqrt(202))
which(dfbetas(rm)[,5]> 2/sqrt(202))
which(dfbetas(rm)[,5]< -2/sqrt(202))
which(dfbetas(rm)[,6]> 2/sqrt(202))
which(dfbetas(rm)[,6]< -2/sqrt(202))
