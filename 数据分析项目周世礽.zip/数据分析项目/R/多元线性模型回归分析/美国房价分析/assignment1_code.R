#(a)
dataframe<-read.csv('housing-1.csv',header=T)
head(dataframe)
attach(dataframe)
rm<-dataframe$rm
plot(nox,medv,type='p')
rm.a<-lm(medv~nox)
abline(rm.a,col='red')
#(b)
summary(rm.a)
n<-length(nox)
par(mfrow=c(2,2))
plot(rm.a,which=c(1,2))
plot(hatvalues(rm.a),main='hatvalues')
abline(h=4/n,col='blue')
plot(cooks.distance(rm.a),type='h',main='CD')
abline(h=qf(0.5,2,n-2),col='red')
#(c)
mfull<-lm(medv~crim+zn+indus+chas+nox+rm+age+dis+rad+tax+ptratio+black+lstat)
summary(mfull)
library(leaps)
mfulls<-regsubsets(medv~crim+zn+indus+chas+nox+rm+age+dis+rad+tax+ptratio+black+lstat,nvmax=14,data=dataframe,method="exhaustive")
modsum=summary(mfulls)
plot(mfulls,scale="bic",col='grey')
modsum$which[10,]
coef(mfulls,10)
rm.c<-lm(medv~crim+chas+nox+rm+dis+rad+tax+ptratio+black+lstat)
summary(rm.c)
plot(rm.c,which=c(1,2))
plot(hatvalues(rm.c),main='hatvalues')
abline(h=22/n,col='blue')
plot(cooks.distance(rm.c),type='h',main='CD')
abline(h=qf(0.5,11,n-11),col='red')
#(d)
par(mfrow=c(1,1))
x<-lstat
y<-medv
plot(x,y,type='p')
rm.d1<-lm(medv~lstat)
rm.d2<-lm(medv~lstat+I(lstat^2))
rm.d3<-lm(medv~lstat+I(lstat^2)+I(lstat^3))
summary(rm.d1)
summary(rm.d2)
summary(rm.d3)
x_range <- seq(min(x), max(x), length.out = 100)
pred1 <- predict(rm.d1,newdata = data.frame(lstat=x_range))
pred2 <- predict(rm.d2, newdata = data.frame(lstat = x_range))
pred3 <- predict(rm.d3, newdata = data.frame(lstat = x_range))
lines(x_range,pred1,col='red',lwd=2)
lines(x_range,pred2,col='blue',lwd=2)
lines(x_range,pred3,col='purple',lwd=2)
legend("topright", 
       legend = c("linear", "quadratic", "cubic"),
       col = c( "red", "blue", "purple"),
       lwd = 2,
       cex = 1.7)
#(e)
#根据adjusted R square，lstat的二次项提升明显，而三次项虽然有提升，但是不是特别明显，所以仅加入二次项
rm.e<-lm(medv~crim+chas+nox+rm+dis+rad+tax+ptratio+black+lstat+I(lstat^2))
summary(rm.e)
summary(rm.c)
#比较二者的拟合结果，发现调整后的r square得到了一定的提升
par(mfrow=c(2,2))
plot(rm.e,which=c(1,2))
plot(hatvalues(rm.e),main='hatvalues')
abline(h=24/n,col='blue')
plot(cooks.distance(rm.a),type='h',main='CD')
abline(h=qf(0.5,12,n-12),col='red')
#(f)
par(mfrow=c(1,1))
rm.f0<-lm(medv~nox,data=dataframe,subset = chas==0)
rm.f1<-lm(medv~nox,data=dataframe,subset=chas==1)
plot(nox,medv,type='p')
abline(rm.f0,col='red')
abline(rm.f1,col='purple')
legend("topright",legend=c("chas=0","chas=1"),col=c("red","purple"),lwd=2,cex=1.3)
#两条回归线的斜率有明显差别，应当加入交互项
rm.f<-lm(medv~crim+chas*nox+rm+dis+rad+tax+ptratio+black+lstat+I(lstat^2))
summary(rm.f)
#(g)
#添加 rm 与 lstat 的交互项，及chas与nox的交互项
rm.g<-lm(medv~crim+chas*nox+rm+dis+rad+tax+ptratio+black+lstat+I(lstat^2)+rm:lstat)
summary(rm.g)
par(mfrow=c(2,2))
plot(rm.g,which=c(1,2))
plot(hatvalues(rm.g),main='hatvalues')
abline(h=28/n,col='blue')
plot(cooks.distance(rm.g),type='h',main='CD')
abline(h=qf(0.5,14,n-14),col='red')
#(h)
par(mfrow=c(1,1))
mfulls_h<-regsubsets(medv~crim+chas*nox+rm+dis+rad+tax+ptratio+black+lstat+I(lstat^2)+rm:lstat,nvmax=14,data=dataframe,method='exhaustive')
modsum=summary(mfulls_h)
plot(mfulls_h,scale="bic",col='grey')
#所以，认为该模型为最优模型
#(i)
model_vars <- all.vars(terms(rm.g))  # 直接获取模型中所有原始变量名
model_vars <- setdiff(model_vars, "medv")  # 排除因变量（如果模型项中包含的话）

# 2. 计算这些协变量的均值
mean_data <- as.data.frame(lapply(dataframe[model_vars], function(x) mean(x, na.rm = TRUE)))

# 3. 生成预测及95%预测区间
pred <- predict(rm.g, newdata = mean_data, interval = "prediction", level = 0.95)
pred
max(medv)
min(medv)
median(medv)
#(j)
boxplot(medv ~ chas, data = dataframe,
        col = c("gray", "blue"),  
        main = "Price of house near Charles River or not",
        xlab = "whether near river（0=Yes，1=No）",
        ylab = "median value of house", 
        notch=FALSE
)

rm_means <- tapply(dataframe$medv, dataframe$rm, mean)


barplot(rm_means[order(names(rm_means))],  # 按房间数从小到大排序
        col = ifelse(names(rm_means) == "2", "red", "lightgreen"),  # 6-7间房（假设rm=2代表该组）标红
        main = "Average house price in different room number",
        xlab = "Group（1: 6 rooms or less，2: 7 rooms，3: 8 rooms or more）",
        ylab = "Average house price",
        ylim = c(0, max(rm_means) * 1.1)  # 预留顶部空间
)

text(1:length(rm_means), rm_means, 
     labels = round(rm_means, 1),  # 保留1位小数
     adj=1,
     col = "black")

pf(3,27,0.4974)
