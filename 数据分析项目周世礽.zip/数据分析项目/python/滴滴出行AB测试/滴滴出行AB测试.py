# -*- coding: utf-8 -*-
"""
Created on Thu Nov 27 12:55:13 2025

@author: book
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import scipy.stats as st #导入python科学计算模块的统计模块部分提供概率分布、统计推断、检验工具等功能
from pandas.core.dtypes.cast import maybe_infer_to_datetimelike#可以直接识别类日期时间格式
from scipy.stats import ttest_ind, mannwhitneyu #双样本t检验和Mann-Whitney U Test（非参数检验），用于小样本，非正态数据，方差不齐数据

test=pd.read_excel('C:/Users/book/Desktop/数据分析项目/滴滴出行AB测试/test.xlsx')
test.head()
test['group'].unique()#检查测试集的分组
control_dates=test[test['group']=='control']['date'].agg(
    ['min','max'])#找出控制组的最小日期和最大日期
exp_dates=test[test['group']=='experiment']['date'].agg(
    ['min','max'])#找出实验组的最小日期和最大日期
test['ROI']=(test['gmv']-test['coupon per trip']*test['trips'])/(test['coupon per trip']*test['trips'])
test.head()
test['conversion']=test['trips']/test['requests']
test['canceled_rate']=test['canceled requests']/test['requests']
test.head()
control=test[test['group']=='control']
experiment=test[test['group']=='experiment']
print(f"控制组有{len(control)}条数据，实验组有{len(experiment)}条数据")
from scipy.stats import shapiro#shapiro wilk检验
features=['requests','gmv','coupon per trip','trips','canceled requests','ROI','conversion','canceled_rate']
for i in features:
    _,p1=shapiro(control[i])
    _,p2=shapiro(experiment[i])
    print(f"指标：{i}")
    print(f"正态性检验，控制组p值{p1}，测试组p值{p2}")
    #_,即占位符，省略shaprio函数的第一个值检验统计量
    _,p_var=st.levene(control[i],experiment[i])
    print(f"方差齐性：{p_var}")
    
    if p1>0.05 and p2>0.05 and p_var>0.05:
        print(f"指标：{i}使用t检验")
    else:
        print(f"指标：{i}需要使用非参数检验（Mann-Whitney U）")
    print("\n")
requests_control=control['requests']
requests_experiment=experiment['requests']
_,p_value=ttest_ind(requests_control,requests_experiment, equal_var=True)
print(f"Requests的p值是：{p_value}")

gmv_control=control['gmv']
gmv_experiment=experiment['gmv']
_,p_value=ttest_ind(gmv_control,gmv_experiment, equal_var=True)
print(f"gmv的p值是：{p_value}")

trips_control=control['trips']
trips_experiment=experiment['trips']
_,p_value=ttest_ind(trips_control,trips_experiment, equal_var=True)
print(f"trips的p值是：{p_value}")

coupon_control=control['coupon per trip']
coupon_experiment=experiment['coupon per trip']
_,p_value=mannwhitneyu(coupon_control,coupon_experiment,alternative='two-sided')
print(f"coupon per trip:{p_value}")

ROI_control=control['ROI']
ROI_experiment=experiment['ROI']
_,p_value=mannwhitneyu(ROI_control,ROI_experiment,alternative='two-sided')
print(f"ROI:{p_value}")

conversion_control=control['conversion']
conversion_experiment=experiment['conversion']
_,p_value=mannwhitneyu(conversion_control,conversion_experiment,alternative='two-sided')
print(f"conversion:{p_value}")

canceled_control=control['canceled_rate']
canceled_experiment=experiment['canceled_rate']
_,p_value=mannwhitneyu(canceled_control,canceled_experiment,alternative='two-sided')
print(f"canceled:{p_value}")
#两组之间仅有取消率的均值出现了明显差异
plt.figure(figsize=(10,5))
ax=test.boxplot(by='group', column='canceled_rate')
ax.set_xlabel('Group')
ax.set_ylabel('Canceled Rate')
plt.show()